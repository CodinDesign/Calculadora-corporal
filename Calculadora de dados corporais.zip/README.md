#Calculadora Fitness

## Funções de cálculo

- IMC: Índice de Massa Corporal;
- TMB: Taxa Metabólica Basal;
- IMM: Índice de Massa Muscular;
- NDC: Necessidades Diárias de Calorias;
- TDEE: Gasto Total diário de Calorias;
- NAN nivel de agua Necessário;

## Informações adicionais

+ Feito por "Codingdesign";
+ app usado "spckEditor";
+ feito no celular;
+ tecnologias usadas "HTML,CSS e JS".